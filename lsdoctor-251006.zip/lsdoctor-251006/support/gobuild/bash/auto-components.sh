# Copyright (c) 2019 VMware, Inc.  All rights reserved.
# VMware Confidential
#
# Support for automatic downloading of gobuild components during
# developer builds.
#
# IN:
#    GOBUILD_TARGET
#    GOBUILD_HOSTTYPE
#    MAINSRCROOT
#    BUILDROOT
#    OBJDIR or BUILDTYPE
#
# OUT:
#    GOBUILD_AUTO_COMPONENTS_DONE
#    GOBUILD_FOO_ROOT for each component 'foo'
#
# usage:
#    ```bash
#    # Set mandatory variables
#    GOBUILD_TARGET=x
#    GOBUILD_HOSTTYPE=y
#    ...
#
#    # Set optional variables; export to pass-through to auto-components.mk.
#    export GOBUILD_AUTO_COMPONENTS_REQUEST=1
#
#    source $MAINSRCROOT/support/gobuild/bash/auto-components.sh
#
#    : ${GOBUILD_FOO_ROOT:?failed to fetch foo}
#    ```

_gobuild_ac_doit() {
   # Since we're `source`-d, assign to local variables to avoid side effects.
   local TCROOT=${TCROOT:-/build/toolchain}
   local BUILDTYPE=${BUILDTYPE:-${OBJDIR:-}}
   local MAKE MAKECMD

   : ${GOBUILD_TARGET:?undefined; choose from support/gobuild/__init__.py}
   : ${GOBUILD_HOSTTYPE:?"undefined; refer to your target's 'GetClusterRequirements' method"}
   : ${MAINSRCROOT:?"undefined; set to parent of 'support/gobuild'"}
   : ${BUILDROOT:?undefined}
   : ${BUILDTYPE:?choose one of obj/opt/beta/release}

   case "$(uname -s | tr [:upper:] [:lower:])" in
      darwin)
         MAKE=$TCROOT/mac32/make-3.82-1/bin/make
         ;;
      linux)
         MAKE=$TCROOT/lin64/make-3.82/bin/make
         ;;
      msys*|mingw*|cygwin*)
         MAKE=$TCROOT/win32/make-3.81/bin/make
         ;;
   esac

   MAKECMD=(
      $MAKE
      -f $MAINSRCROOT/support/gobuild/make/auto-components.mk
      --quiet
      TCROOT=$TCROOT
      GOBUILD_TARGET=$GOBUILD_TARGET
      MAINSRCROOT=$MAINSRCROOT
      BUILDROOT=$BUILDROOT
      OBJDIR=$BUILDTYPE
      GOBUILD_AUTO_COMPONENTS=${GOBUILD_AUTO_COMPONENTS:-1}
      GOBUILD_AUTO_COMPONENTS_HOSTTYPE=$GOBUILD_HOSTTYPE
   )
   "${MAKECMD[@]}"

   local SPECINFO="$BUILDROOT/$BUILDTYPE/gobuild/specinfo/${GOBUILD_TARGET}.bash"
   if ! [[ -f $SPECINFO ]] ; then
      echo >&2 "Gobuild scriptlet $SPECINFO not created"
      exit 1
   fi
   . $SPECINFO
}

_gobuild_ac_doit

# vim: sw=3 sts=3:
