# Copyright 2008 VMware, Inc.  All rights reserved. -- VMware Confidential
"""
LsDoctor gobuild product module.
"""
import helpers.target

LINUX_HOSTTYPE = 'linux-rocky8-vm-fw'

class LsDoctor(helpers.target.Target):
    """
    LS Doctor

    Creates a build that create lsdoctor.zip.
    """

    def __init__(self):
        self.target = "lsdoctor-zip"

    def GetBuildProductNames(self):
        return {'name': self.target,
                'longname': 'Gobuild Starter Kit - LS Doctor'}

    def GetClusterRequirements(self):
        return [LINUX_HOSTTYPE]

    def GetRepositories(self, hosttype):
        repos = [{
            'rcs': 'github',
            'src': 'vcf/lsdoctor.git;%(branch);',
            'dst': 'src',
        }]
        return repos


    def GetCommands(self, hosttype):
        return [{
            'desc': 'Running lsdoctor build',
            'root': '%(buildroot)/src',
            'log': 'lsdoctor.log',
            'command': 'mkdir %(buildroot)/publish/lsdoctor;zip -r %(buildroot)/publish/lsdoctor/lsdoctor.zip .',
        }]

    def GetStorageInfo(self, hosttype):
        return []

    def GetBuildProductVersion(self, hosttype):
        return "1.0.0"
