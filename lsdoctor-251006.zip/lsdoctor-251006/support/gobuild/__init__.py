# Copyright 2008-2022 VMware, Inc.  All rights reserved.
# VMware Confidential
"""
Support code for building products with gobuild.
"""
import helpers
import helpers.access
import targets.lsdoctor

# The TARGETS dictionary maps a target's name to its class that
# implements the gobuild Target interface. Make sure to import
# your target module above.
TARGETS = {
    'lsdoctor': targets.lsdoctor.LsDoctor,
}

# Add an access target for each already-defined target.
for name, cls in TARGETS.copy().iteritems():
    if name.endswith('-access'):
        # This is an access target, don't add an access-access target.
        continue
    accessname = '%s-access' % name
    if accessname in TARGETS:
        # There's already an access target defined.
        continue
    TARGETS[accessname] = helpers.access.MakeAccessTarget(name, cls)


def GetTarget(log, name):
    """
    Return the Target class for the build identified by the target
    'name'.  The log parameter is a standard python logging object
    which can be used to write to the gobuild log if you like.
    """
    objtype = TARGETS.get(name)
    if not objtype:
        return None

    return objtype()


def GetAllTargets(log):
    """
    Return a list of all targets that can be built from this
    branch.
    """
    return TARGETS.keys()


def GetBranch(log):
    """
    Return the name of the branch.
    """
    return helpers.GetBranch()
