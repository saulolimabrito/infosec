# Copyright 2008 VMware, Inc.  All rights reserved. -- VMware Confidential

"""
Helpers for msbuild-based targets.
"""

import os


class MsBuildHelper:
    """
    Helper class for targets that build with msbuild.
    Meant to be used as a mixin with helpers.target.Target. Provides a
    private method _Command() that helps to create a msbuild command.
    Please see helpers/target.py for detail usages on GetCommands.
    To change the version of MSBuild, change the msbuild/msbuild.bat file

       >>> import helpers.env
       >>> import helpers.target
       >>> import helpers.msbuild
       >>>
       >>> class HelloWorld(helpers.target.Target,
       ...                  helpers.msbuild.MsBuildHelper):
       ...    def GetCommands(self, hosttype):
       ...       # MSBuild target name to be executed to build project.
       ...       target = 'helloworld'
       ...       # MSBuild flags to be passed in.
       ...       flags = {'PRODUCT': 'hello'}
       ...       # Root directory, from where MSBuild command is to be executed.
       ...       root = '%(buildroot)'
       ...       # Environment settings under where MSBuild command is
       ...       # to be executed.
       ...       env = helpers.env.SafeEnvironment(hosttype)
       ...       return [ { 'desc'    : 'Running hello world sample',
       ...                  'root'    : root,
       ...                  'log'     : '%s.log' % target,
       ...                  'command' : self._Command(
       ...                                  hosttype, target, **flags),
       ...                  'env'     : env,
       ...                } ]
       >>>
    """

    def _Command(self, hosttype, targets, msbuildversion=8.1, **flags):
        """
        Return a dictionary representing a command to invoke MSBuild with
        standard MSBuildflags.
        """

        def q(s):
            return '"%s"' % s

        defaults = {
            'GOBUILD_OFFICIAL_BUILD': '1',
            'GOBUILD_AUTO_COMPONENTS': 'false',
            'OBJDIR': q('%(buildtype)'),
            'RELTYPE': q('%(releasetype)'),
            'BUILD_NUMBER': q('%(buildnumber)'),
            'PRODUCT_BUILD_NUMBER': q('%(productbuildnumber)'),
            'CHANGE_NUMBER': q('%(changenumber)'),
            'BRANCH_NAME': q('%(branch)'),
            'PUBLISH_DIR': q('%(buildroot)/publish'),
            'BUILDLOG_DIR': q('%(logdir)'),
            'REMOTE_COPY_SCRIPT': q('%(gobuildc) %(buildid)'),
        }

        # Add a GOBUILD_*_ROOT flag for every component we depend on.
        for d, is_url_enabled in self.GetComponentDependencyAliases():
            d = d.replace('-', '_')
            defaults['GOBUILD_%s_ROOT' % d.upper()] = \
                '%%(gobuild_component_%s_root)' % d
            if is_url_enabled:
                defaults['GOBUILD_%s_URL' % d.upper()] = \
                    '%%(gobuild_component_%s_url)' % d

        # Override the defaults above with the options passed in by
        # the client.
        defaults.update(flags)

        if hosttype.startswith('windows'):
            tcroot = os.environ.get('TCROOT', 'C:/TCROOT-not-set')
            msbuildcmd = ('%s/win32/winddk-%s/MSBuild.bat' %
                        (tcroot, msbuildversion))
        else:
            # msbuild is windows specific tool
            return None

        # Create the command line to invoke MSBuild
        target = targets
        if isinstance(targets, (list, tuple)):
            target = ';'.join(targets)
        cmd = '%s /target:%s ' % (msbuildcmd, target)
        for k in sorted(defaults.keys()):
            v = defaults[k]
            if k.startswith('/'):
                # MSBuild option
                cmd += ' ' + str(k)
                if v is not None and str(v).strip() != '':
                    cmd += ' ' + str(v)
            else:
                # MSBuild property
                cmd += ' /property:' + str(k)
                if v is not None:
                    cmd += '=' + str(v)

        return cmd
